<h1 align="center">如何为本项目提交Pull Request</h1>

[GitHub的 Pull Request 是指什么](zhihu.com/question/21682976)

**图片等到项目创立再传**

一、Fork一份该项目到自己的仓库中。

![](http://leiblog.wang/static/image/2020/6/7DUigv.png)

二、进到自己fork的项目中，Clone或者Download Zip 下载到本地。

![](http://leiblog.wang/static/image/2020/6/w0YuFz.png)

三、在主分支或者自己创建一个新的分支(比较推荐新建分支)，修改，递交。

四、在自己的仓库里找到New Pull Request、递交分支。
![](http://leiblog.wang/static/image/2020/6/99mRa7.png)
![](http://leiblog.wang/static/image/2020/6/iqfVQt.png)

五、我来Review你的递交，决定是否合并。

> 如果有PDF图书或其他资源需要上传，可以联系我上传
>
> CONTACT:
>
> QQ: 2230647190
>
> Wechat: wanglei199901
>
> E-mail:2230647190@qq.com